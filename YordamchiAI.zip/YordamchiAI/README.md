# Yordamchi AI — Android ilova

Telefonni boshqaruvchi AI yordamchi: qo'ng'iroqlarni skrining qilish, SMS'ga avtomatik javob/filtrlash va ovozli buyruq bilan eslatma qo'shish.

## Nima qiladi

1. **Qo'ng'iroq skrining** — noma'lum yoki qora ro'yxatdagi raqamlardan qo'ng'iroqlarni avtomatik rad etadi (`CallScreeningServiceImpl.kt`).
2. **SMS boshqaruvi** — spam kalit so'zlarni filtrlaydi va (yoqilgan bo'lsa) kiruvchi xabarlarga avtomatik javob yuboradi (`SmsReceiver.kt`).
3. **Eslatmalar** — matn yoki ovoz orqali vazifa kiritilsa, tizim `AlarmManager` orqali aniq vaqtda bildirishnoma yuboradi (`ReminderManager.kt`, `AlarmReceiver.kt`).
4. **Ovozli kiritish** — mikrofon tugmasi orqali vazifa matnini ovoz bilan aytish mumkin (Android nutqni matnga aylantirish xizmati orqali).

## Loyihani ochish va build qilish

1. [Android Studio](https://developer.android.com/studio) o'rnating (Hedgehog yoki undan yangi versiya tavsiya etiladi).
2. `File > Open` orqali ushbu papkani (`YordamchiAI`) oching.
3. Gradle avtomatik sinxronlanishini kuting (internet aloqasi kerak).
4. Telefoningizni USB orqali ulang (Developer Options > USB debugging yoqilgan bo'lishi kerak) yoki emulyator ishga tushiring.
5. `Run ▶` tugmasini bosing.

## Ilovani ishga tushirgandan keyin

- **"Barcha ruxsatlarni berish"** tugmasini bosing — SMS, qo'ng'iroq va mikrofon ruxsatlarini bering.
- **"Qo'ng'iroq skriningini yoqish"** tugmasini bosing — tizim sozlamalarida ushbu ilovani standart skrining ilovasi sifatida tasdiqlang.
- **SMS avtomatik javob** va **Noma'lum raqamlarni rad etish** o'zgartkichlarini xohishingizga qarab yoqing.
- Pastdagi maydonga vazifa yozing (yoki 🎤 tugmasi orqali ayting) va **"1 soatdan keyin eslat"** tugmasini bosing.

## Muhim eslatmalar

- Android xavfsizlik siyosatiga ko'ra, SMS va qo'ng'iroqlarni to'liq boshqarish faqat foydalanuvchi tizim sozlamalaridan **aniq ruxsat bergandan keyin** ishlaydi — bu ilova ham shu qoidaga bo'ysunadi.
- `SmsReceiver.kt` ichidagi `SPAM_KEYWORDS` ro'yxatini va `CallScreeningServiceImpl.kt` ichidagi bloklash mantig'ini o'z ehtiyojingizga qarab kengaytirishingiz mumkin.
- Hozirgi "vazifa qo'shish" tugmasi namunada har doim 1 soatdan keyinga eslatma qo'yadi. Aniq sana/vaqtni ovozdan avtomatik ajratib olish uchun (masalan "ertaga soat 9 da") tabiiy tilni tahlil qiluvchi qo'shimcha kutubxona (masalan, kalit so'zlarga asoslangan oddiy parser yoki tashqi AI API) qo'shish tavsiya etiladi — buni keyingi bosqichda birga qo'shishimiz mumkin.
- Ilova minimal ishlaydigan skelet sifatida yozilgan; ishlab chiqarishga (Play Store) chiqarishdan oldin xatoliklarni ushlash, sozlamalar ekrani va UI sayqallashni qo'shish tavsiya etiladi.
