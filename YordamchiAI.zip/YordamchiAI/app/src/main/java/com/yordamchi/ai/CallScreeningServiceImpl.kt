package com.yordamchi.ai

import android.content.Context
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.CallScreeningService.CallResponse

/**
 * Noma'lum yoki qora ro'yxatdagi raqamlardan qo'ng'iroqlarni avtomatik rad etadi.
 * Foydalanuvchi buni Sozlamalar > Ilovalar > Standart ilovalar > Qo'ng'iroqni skrining qilish
 * bo'limida ushbu ilovani tanlashi orqali faollashtiradi.
 */
class CallScreeningServiceImpl : CallScreeningService() {

    companion object {
        const val PREFS = "yordamchi_call_settings"
        const val KEY_BLOCK_UNKNOWN = "block_unknown_numbers"
        const val KEY_BLOCKLIST = "blocked_numbers" // vergul bilan ajratilgan raqamlar
    }

    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart ?: ""
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val blockUnknown = prefs.getBoolean(KEY_BLOCK_UNKNOWN, false)
        val blockedNumbers = prefs.getString(KEY_BLOCKLIST, "")
            ?.split(",")
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?: emptyList()

        val isBlocked = blockedNumbers.contains(number)
        val isUnknown = number.isBlank()

        val response = CallResponse.Builder()

        if (isBlocked || (blockUnknown && isUnknown)) {
            response.setDisallowCall(true)
            response.setRejectCall(true)
            response.setSkipCallLog(false)
            response.setSkipNotification(false)
        } else {
            response.setDisallowCall(false)
        }

        respondToCall(callDetails, response.build())
    }
}
