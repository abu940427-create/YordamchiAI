package com.yordamchi.ai

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.switchmaterial.SwitchMaterial
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private val requiredPermissions = arrayOf(
        Manifest.permission.SEND_SMS,
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.POST_NOTIFICATIONS
    )

    private val permissionRequestCode = 101
    private val voiceRequestCode = 202
    private val callScreeningRequestCode = 303

    private lateinit var listTasks: ListView
    private lateinit var inputTask: EditText
    private lateinit var taskAdapter: ArrayAdapter<String>
    private var tasks = mutableListOf<Task>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnPermissions = findViewById<Button>(R.id.btnPermissions)
        val btnCallScreening = findViewById<Button>(R.id.btnCallScreening)
        val switchAutoReply = findViewById<SwitchMaterial>(R.id.switchAutoReply)
        val switchBlockUnknown = findViewById<SwitchMaterial>(R.id.switchBlockUnknown)
        val btnVoice = findViewById<Button>(R.id.btnVoice)
        val btnAddTask = findViewById<Button>(R.id.btnAddTask)
        inputTask = findViewById(R.id.inputTask)
        listTasks = findViewById(R.id.listTasks)

        // --- Ruxsatlar ---
        btnPermissions.setOnClickListener { requestAllPermissions() }

        // --- Qo'ng'iroq skriningini standart ilova sifatida so'rash (Android 10+) ---
        btnCallScreening.setOnClickListener { requestCallScreeningRole() }

        // --- SMS avtomatik javob sozlamasi ---
        val smsPrefs = getSharedPreferences(SmsReceiver.PREFS, Context.MODE_PRIVATE)
        switchAutoReply.isChecked = smsPrefs.getBoolean(SmsReceiver.KEY_AUTO_REPLY_ENABLED, false)
        switchAutoReply.setOnCheckedChangeListener { _, isChecked ->
            smsPrefs.edit().putBoolean(SmsReceiver.KEY_AUTO_REPLY_ENABLED, isChecked).apply()
            Toast.makeText(this, if (isChecked) "Avtomatik javob yoqildi" else "Avtomatik javob o'chirildi", Toast.LENGTH_SHORT).show()
        }

        // --- Noma'lum raqamlarni bloklash sozlamasi ---
        val callPrefs = getSharedPreferences(CallScreeningServiceImpl.PREFS, Context.MODE_PRIVATE)
        switchBlockUnknown.isChecked = callPrefs.getBoolean(CallScreeningServiceImpl.KEY_BLOCK_UNKNOWN, false)
        switchBlockUnknown.setOnCheckedChangeListener { _, isChecked ->
            callPrefs.edit().putBoolean(CallScreeningServiceImpl.KEY_BLOCK_UNKNOWN, isChecked).apply()
        }

        // --- Ovozli buyruq bilan vazifa matnini kiritish ---
        btnVoice.setOnClickListener { startVoiceInput() }

        // --- Vazifa/eslatma qo'shish (namunada: 1 soatdan keyin eslatadi) ---
        btnAddTask.setOnClickListener {
            val text = inputTask.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "Avval matn kiriting", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val time = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1) }.timeInMillis
            val task = Task(id = System.currentTimeMillis(), title = text, timeMillis = time)
            TaskStorage.add(this, task)
            ReminderManager.schedule(this, task)
            inputTask.setText("")
            refreshTaskList()
            Toast.makeText(this, "Eslatma o'rnatildi: 1 soatdan keyin", Toast.LENGTH_SHORT).show()
        }

        taskAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        listTasks.adapter = taskAdapter
        listTasks.setOnItemLongClickListener { _, _, position, _ ->
            val task = tasks[position]
            TaskStorage.remove(this, task.id)
            ReminderManager.cancel(this, task)
            refreshTaskList()
            Toast.makeText(this, "O'chirildi: ${task.title}", Toast.LENGTH_SHORT).show()
            true
        }

        refreshTaskList()
        requestAllPermissions()
    }

    private fun refreshTaskList() {
        tasks = TaskStorage.getAll(this)
        taskAdapter.clear()
        taskAdapter.addAll(tasks.map { it.title })
        taskAdapter.notifyDataSetChanged()
    }

    private fun requestAllPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), permissionRequestCode)
        } else {
            Toast.makeText(this, "Barcha ruxsatlar allaqachon berilgan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestCallScreeningRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            if (roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                if (!roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING)
                    startActivityForResult(intent, callScreeningRequestCode)
                } else {
                    Toast.makeText(this, "Qo'ng'iroq skrining allaqachon yoqilgan", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Bu qurilmada qo'ng'iroq skrining mavjud emas", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Qo'ng'iroq skrining uchun Android 10+ kerak", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Vazifangizni ayting...")
        }
        try {
            startActivityForResult(intent, voiceRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Ovozli kiritish qo'llab-quvvatlanmaydi", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequestCode && resultCode == Activity.RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = results?.firstOrNull()
            if (spoken != null) {
                inputTask.setText(spoken)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            val allGranted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            Toast.makeText(
                this,
                if (allGranted) "Barcha ruxsatlar berildi ✅" else "Ba'zi ruxsatlar berilmadi",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
