package com.yordamchi.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Telefon qayta yoqilganda barcha faol eslatmalarni qayta rejalashtiradi. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderManager.rescheduleAll(context)
        }
    }
}
