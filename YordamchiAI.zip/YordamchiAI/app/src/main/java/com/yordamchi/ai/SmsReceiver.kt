package com.yordamchi.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsManager

/**
 * Kiruvchi SMS xabarlarni ushlaydi:
 *  - AlLOWLIST_KEYWORDS ro'yxatidagi so'zlar bo'lsa -> muhim deb belgilaydi
 *  - SPAM_KEYWORDS bo'lsa -> e'tiborsiz qoldiradi (log qiladi, bildirishnoma bermaydi)
 *  - "band" / band bo'lsangiz -> avtomatik javob yuboradi (agar foydalanuvchi shu rejimni yoqqan bo'lsa)
 *
 * Eslatma: bu oddiy kalit-so'zga asoslangan filtr namunasi. Ishlab chiqarish uchun
 * buni sozlamalar ekrani orqali foydalanuvchi tomonidan sozlanadigan qilish tavsiya etiladi.
 */
class SmsReceiver : BroadcastReceiver() {

    companion object {
        private val SPAM_KEYWORDS = listOf("kredit", "yutuq", "sovg'a", "bepul pul", "http://bit.ly")
        const val PREFS = "yordamchi_sms_settings"
        const val KEY_AUTO_REPLY_ENABLED = "auto_reply_enabled"
        const val KEY_AUTO_REPLY_TEXT = "auto_reply_text"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        for (sms in messages) {
            val sender = sms.originatingAddress ?: continue
            val body = sms.messageBody ?: ""

            val isSpam = SPAM_KEYWORDS.any { body.contains(it, ignoreCase = true) }
            if (isSpam) {
                // Spam sifatida belgilanadi, bildirishnoma bosilmaydi.
                // Bu yerda kelajakda log/blocklist bazasiga yozish mumkin.
                continue
            }

            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val autoReplyOn = prefs.getBoolean(KEY_AUTO_REPLY_ENABLED, false)
            if (autoReplyOn) {
                val replyText = prefs.getString(
                    KEY_AUTO_REPLY_TEXT,
                    "Salom! Hozir band man, tez orada javob beraman. (Avtomatik javob — Yordamchi AI)"
                )
                sendReply(context, sender, replyText ?: "")
            }
        }
    }

    private fun sendReply(context: Context, to: String, message: String) {
        try {
            val smsManager = context.getSystemService(SmsManager::class.java)
                ?: SmsManager.getDefault()
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(to, null, parts, null, null)
        } catch (e: SecurityException) {
            // SEND_SMS ruxsati berilmagan bo'lishi mumkin.
        }
    }
}
