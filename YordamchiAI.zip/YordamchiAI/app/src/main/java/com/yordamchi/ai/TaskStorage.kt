package com.yordamchi.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Vazifa/eslatmalarni telefon xotirasida (SharedPreferences) JSON ko'rinishida saqlaydi.
 * Katta loyihalarda buning o'rniga Room bazasidan foydalanish tavsiya etiladi.
 */
object TaskStorage {
    private const val PREFS = "yordamchi_tasks"
    private const val KEY_TASKS = "tasks_json"

    fun getAll(context: Context): MutableList<Task> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_TASKS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<Task>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(Task(o.getLong("id"), o.getString("title"), o.getLong("time")))
        }
        return list
    }

    fun add(context: Context, task: Task) {
        val list = getAll(context)
        list.add(task)
        saveAll(context, list)
    }

    fun remove(context: Context, id: Long) {
        val list = getAll(context).filterNot { it.id == id }.toMutableList()
        saveAll(context, list)
    }

    private fun saveAll(context: Context, list: List<Task>) {
        val arr = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("title", t.title)
            o.put("time", t.timeMillis)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TASKS, arr.toString())
            .apply()
    }
}
