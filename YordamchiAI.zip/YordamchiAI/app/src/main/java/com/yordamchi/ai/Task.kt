package com.yordamchi.ai

/** Bitta vazifa/eslatma elementi. */
data class Task(
    val id: Long,
    val title: String,
    val timeMillis: Long
)
